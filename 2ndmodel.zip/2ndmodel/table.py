from tkinter import *
from tkinter import ttk
import pymysql

# Database Connection
con = pymysql.connect(host="localhost", user="root", password="", database="datetry")
# create cursor
my_cursor = con.cursor()

# create root window
root = Tk()
root.title("Table")

# create a style for the treeview
style = ttk.Style()
style.theme_use("default")
style.configure("Treeview",
                background="#D3D3D3",
                foreground="black",
                rowheight=25,
                fieldbackground="#D3D3D3",
                font=("Arial", 10, ))
style.map('Treeview', background=[('selected', '#347083')])

# create treeview with vertical scrollbar
tree = ttk.Treeview(root)
tree.pack(side='left', fill='both', expand=True)

vsb = ttk.Scrollbar(root, orient="vertical", command=tree.yview)
vsb.pack(side='right', fill=Y)

tree.configure(yscrollcommand=vsb.set)
tree["columns"] = ("1", "2", "3", "4")
tree.column("#0", width=0, stretch=NO)
tree.column("1", anchor=W, width=80)
tree.column("2", anchor=W, width=120)
tree.column("3", anchor=CENTER, width=150)
tree.column("4", anchor=CENTER, width=150)
tree.heading("#0", text="", anchor=W)
# fetch data from MySQL table and insert into treeview
tree.heading("1", text="Number of ID", anchor=W)
tree.heading("2", text="Characters", anchor=W)
tree.heading("3", text="Curr Date Time In", anchor=CENTER)
tree.heading("4", text="Curr Date Time Out", anchor=CENTER)


# fetch data from MySQL table and insert into treeview
my_cursor.execute("SELECT * FROM daythree ")
rows = my_cursor.fetchall()
for row in rows:
    tree.insert("", END, text="", values=row)

root.geometry("515x400")

# Get column names
column_names = ["id", "chars", "curr_date_time_in", "curr_date_time_out"]

# Create scrollable frame
canvas = Canvas(root)
canvas.pack(side=LEFT, fill=BOTH, expand=True)

scrollbar = Scrollbar(root, orient=VERTICAL, command=canvas.yview)
scrollbar.pack(side=RIGHT, fill=Y)

canvas.configure(yscrollcommand=scrollbar.set)
canvas.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox("all")))

frame = Frame(canvas)
canvas.create_window((0, 0), window=frame, anchor="nw")

# Display column names
for j, header in enumerate(column_names):
    if header == "id":
        width = 7  # set larger width for id column name
        label_text = "No. Of ID"  # set longer name for id column
        anchor = "w"  # align id column header to left
    elif header == "chars":
        width = 20  # set larger width for chars column name
        label_text = "Characters"
        anchor = "e"
    else:
        width = 15  # set default width for other columns
        label_text = header
        anchor = "w"  # align other column headers to left

   

# Run main loop 
root.mainloop()

# Close database connection
con.close()
