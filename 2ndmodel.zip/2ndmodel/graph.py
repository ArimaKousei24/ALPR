import cv2
import numpy as np

net = cv2.dnn.readNet("yolov4-tiny-custom_best.weights", "yolov4-tiny-custom.cfg")
model = cv2.dnn_DetectionModel(net)
model.setInputParams(size=(320, 320), scale=1/255)

classes = []
with open("classes.txt", "r") as file_object:
    for class_name in file_object.readlines():
        class_name = class_name.strip()
        classes.append(class_name)

def generate_map(model, classes, img_path):
    # Load the input image
    img = cv2.imread(img_path)
    
    # Resize the input image to (320, 320)
    img = cv2.resize(img, (320, 320))

    # Preprocess the image to be compatible with the model input shape
    img = img.astype(np.float32) / 255.0
    img = np.expand_dims(img, axis=0)

    # Run inference on the image using the model
    results = model.detect(img)

    # Post-process the model output to extract the detected objects and their locations
    class_ids, confidences, boxes = [], [], []
    for result in results:
        for detection in result:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.5:
                center_x = int(detection[0] * img.shape[2])
                center_y = int(detection[1] * img.shape[1])
                width = int(detection[2] * img.shape[2])
                height = int(detection[3] * img.shape[1])
                left = int(center_x - width / 2)
                top = int(center_y - height / 2)
                class_ids.append(class_id)
                confidences.append(float(confidence))
                boxes.append([left, top, width, height])

    # Draw the detected objects on the image and create a map graph
    map_graph = np.zeros((img.shape[1], img.shape[2]))
    for i in range(len(boxes)):
        left, top, width, height = boxes[i]
        class_id = class_ids[i]
        color = (0, 255, 0) if class_id == 0 else (0, 0, 255)
        cv2.rectangle(img[0], (left, top), (left + width, top + height), color, 2)
        x = int((left + width / 2) * map_graph.shape[1] / img.shape[2])
        y = int((top + height / 2) * map_graph.shape[0] / img.shape[1])
        map_graph[y, x] = 1

    # Display the image and the map graph
    cv2.imshow("Image", img[0])
    cv2.imshow("Map Graph", map_graph)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

# Call the function with the path to your input image
generate_map(model, classes, "51.jpg")
