import cv2
import numpy as np

# Load the model
net = cv2.dnn.readNet("yolov4-tiny-custom_best.weights", "yolov4-tiny-custom.cfg")

# Load the image
img = cv2.imread('49.jpg')

# Get the height and width of the image
height, width = img.shape[:2]

# Define the input blob
blob = cv2.dnn.blobFromImage(img, 1/255, (416, 416), [0,0,0], 1, crop=False)

# Set the input blob to the model
net.setInput(blob)

# Get the output from the model
output_layers = net.getUnconnectedOutLayersNames()
outputs = net.forward(output_layers)

# Prepare the class labels and colors for drawing the bounding boxes
classes = ["license plate"]
colors = np.random.uniform(0, 255, size=(len(classes), 3))

# Loop through all the detections and draw the bounding boxes
for output in outputs:
    for detection in output:
        scores = detection[5:]
        class_id = np.argmax(scores)
        confidence = scores[class_id]
        if confidence > 0.5:
            x, y, w, h = int(detection[0] * width), int(detection[1] * height), int(detection[2] * width), int(detection[3] * height)
            cv2.rectangle(img, (x, y), (x + w, y + h), colors[class_id], 2)
            label = f"{classes[class_id]}: {confidence:.2f}"
            cv2.putText(img, label, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, colors[class_id], 2)

# Show the image with the bounding boxes
resized_img = cv2.resize(img, (800, 600))  # resize to 800x600
cv2.imshow("Detected license plates", img)
cv2.waitKey(0)
