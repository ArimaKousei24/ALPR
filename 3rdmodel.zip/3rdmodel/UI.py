import tkinter as tk
from tkinter import filedialog
from tkinter import messagebox
import os
from PIL import Image, ImageTk
import subprocess


class Application(tk.Frame):
    def __init__(self, master=None):
        tk.Frame.__init__(self, master, bg="white")
        self.pack(fill="both", expand=True)

        self.create_widgets()

    def create_widgets(self):
        self.background_image = ImageTk.PhotoImage(file="cypher.png")
        self.background = tk.Label(self, image=self.background_image)
        self.background.pack(fill="both", expand=False)
        self.background.place(relx=0.5, rely=0.35, anchor="center")

        self.open_file_button = tk.Button(self, height=2, width=20, font=("Helvetica", 16), bg='#3f3f3f', fg='white')
        self.open_file_button["text"] = "Open Main File"
        self.open_file_button["command"] = self.open_file
        self.open_file_button.pack(pady=1)
        self.open_file_button.place(relx=0.5, rely=0.75, anchor="center")

        self.table_button = tk.Button(self, height=2, width=20, font=("Helvetica", 16), bg='#3f3f3f', fg='white')
        self.table_button["text"] = "Table"
        self.table_button["command"] = self.open_table
        self.table_button.pack(pady=1)
        self.table_button.place(relx=0.5, rely=0.85, anchor="center")

        self.quit = tk.Button(self, text="Quit", height=2, width=20, font=("Helvetica", 16), bg='#3f3f3f', fg='white', command=self.master.destroy)
        self.quit.pack(pady=1)
        self.quit.place(relx=0.5, rely=0.95, anchor="center")


    def open_file(self):
        top_alpr = tk.Toplevel(self.master)
        top_alpr.title("Main File")
        top_alpr.geometry("500x500")
    # You can modify the path to alpr.py as needed
        process = subprocess.Popen(['python', 'alpr.py'])
        process.wait()
        top_alpr.destroy()

    # def open_table(self):
    #     if not hasattr(self, "top_table") or not self.top_table.winfo_exists():
    #         self.top_table = tk.Toplevel(self.master)
    #         self.top_table.protocol("WM_DELETE_WINDOW", self.destroy_table)
    #         self.top_table.title("Table")
    #         self.top_table.geometry("500x500")
    #     # You can modify the path to table.py as needed
    #         subprocess.call(['python', 'table.py'])
    #     else:
    #         self.top_table.lift()

    # def destroy_table(self):
    #     self.top_table.destroy()

    def open_table(self):
        top_alpr = tk.Toplevel(self.master)
        top_alpr.title("Table")
        top_alpr.geometry("500x500")
    # You can modify the path to alpr.py as needed
        process = subprocess.Popen(['python', 'table.py'])
        process.wait()
        top_alpr.destroy()
        



root = tk.Tk()
root.geometry("500x600")
root.eval('tk::PlaceWindow . center')
root.geometry("500x600+{}+{}".format(
    int((root.winfo_screenwidth() - 500) / 2),
    int((root.winfo_screenheight() - 600) / 2)
))
root.config(bg='white')
root.title("Cypher View")
app = Application(master=root)
app.mainloop()
